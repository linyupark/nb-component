// NbComponent: CommonJS Main
module.exports = require('../esm/index.js');