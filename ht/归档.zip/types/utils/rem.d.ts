declare function setRem(): void;
declare function noRem(): void;
export { setRem, noRem };
